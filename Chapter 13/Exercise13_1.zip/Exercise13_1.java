package exercise13_1;


import java.util.Scanner;

public class Exercise13_1 {
	
	private double side1 = 1; 
	private double side2 = 1; 
	private double side3 = 1; 

	public static void main(String[] args) {
		Scanner input = new Scanner(System.in);
		
		System.out.println("Please enter three sides of the triangle: ");
		double side1 = input.nextDouble();
		double side2 = input.nextDouble();
		double side3 = input.nextDouble(); 
		Triangle triangleTest = new Triangle(side1, side2, side3);
		
		System.out.println("Please enter a color: ");
		triangleTest.setColor(input.next()); 
		
		System.out.println("Is the triangle filled? 'True' or 'False'");
		triangleTest.setFilled(input.next());
		
		
		System.out.println("Area is: " + triangleTest.getArea());
		System.out.println("Perimeter is: " + triangleTest.getPerimeter());
		System.out.println("The Color of the Triangle is " + triangleTest.getColor());
        System.out.println("Is the Triangle filled? " + triangleTest.isFilled());

	}

}
