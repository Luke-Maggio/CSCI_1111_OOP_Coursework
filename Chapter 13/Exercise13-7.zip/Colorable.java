package exercise13_7;


public interface Colorable {
	
		public abstract String howToColor();
		
}

