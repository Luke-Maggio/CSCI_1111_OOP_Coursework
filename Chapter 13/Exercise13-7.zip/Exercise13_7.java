package exercise13_7;

public class Exercise13_7 {

	public static void main(String[] args) {
		
		GeometricObject[] Triangles = {new Triangle(1, 1, 1), new Triangle(3, 4, 5),
				new Triangle(5, 5, 5), new Triangle(2, 2, 2), new Triangle( 7, 6, 7)};
		
		for( int i = 0; i < Triangles.length; i++) {
			System.out.println("Triangle " + (i + 1));
			System.out.println("Area: " + Triangles[i].getArea());
			System.out.println("How to Color: " + (Triangles[i].howToColor()));
		}

	}

}
