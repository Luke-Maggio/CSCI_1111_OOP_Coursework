package exercise13_11;

public class Octagon extends GeometricObject implements Cloneable,
Comparable<Octagon> {

	private double side;
	
	public Octagon() {
	
	}
	
	public Octagon(double side) {
		this.side = side;
	
	}
	
	public double setSide(double side) {
		return this.side;
		
	}
	
	public double getSide(double side) {
		return side; 
		
	}
	@Override
	public double getArea() {
		return (2 + 4 / Math.sqrt(2) * side * side);
		
	}
	/*use -1, 0, and 1 in if else statement to compare the area
	 * of the two octagons
	 */
	@Override
	public int compareTo(Octagon o) {
		if (getArea() < o.getArea())
			return -1;
		else if (getArea() > o.getArea())
			return 1;
		else 
			return 0;
		
	}
	@Override
	public Object clone() throws CloneNotSupportedException {
		return super.clone();
	
	}
	@Override
	public String toString() {
		return super.toString() + "Area: " + getArea();
	}
}
