package exercise13_11;

public class Exercise13_11 {

	public static void main(String[] args) throws CloneNotSupportedException {
		
		Octagon OctagonTest = new Octagon(3);
		
		
		System.out.println("The Octagon Area: " + OctagonTest.getArea());
		System.out.println("Are the Octagons clones? ");
		
		Octagon OctagonTest2 = (Octagon)OctagonTest.clone();
		
		int result = (OctagonTest.compareTo(OctagonTest2));
		
		/*use -1, 0, and 1 to assign print statements for 
		 * different cases
		 * 
		 */
		if (result == -1)
			System.out.println("The original octagon has less area than its clone");
		else if (result == 1)
			System.out.println("The original octagon has more area than its clone");
		else 
			System.out.println("Octagon 2 is a clone of Octagon 1");
	}

}
